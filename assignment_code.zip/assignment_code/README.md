Solution.ipynb contains the solution
New_Heart_Disease_Model.ipynb contains solution for the new model